//
//  NSString+Parser.m
//  aws_OCR
//
//  Created by FFine on 2019/7/24.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "NSString+Parser.h"

@implementation NSString (Parser)

-(NSRange)dateStrRange{
    NSString *dateRegex = @"\\d{1,4}[/-]\\d{1,4}[/-]\\d{1,4}";
    NSRange dateRange = [self rangeOfString:dateRegex options:NSRegularExpressionSearch];
    return dateRange;
}
-(NSDateComponents *)parseDate:(NSRange)range{
    NSString *dateStr = [self substringWithRange:range];
    NSArray<NSString *> *components = [dateStr componentsSeparatedByString:@"-"];
    
    if (components.count==1) {
        components = [dateStr componentsSeparatedByString:@"/"];
    }
    int year = [components objectAtIndex:2].intValue;
    int month = [components objectAtIndex:0].intValue;
    if (month > 12) {
        month = month % 10;
    }
    int day = [components objectAtIndex:1].intValue;
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:year];
    [comps setMonth:month];
    [comps setDay:day];
    [comps setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"] ];
//    NSCalendar *cal = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
//    NSDate *referenceTime = [cal dateFromComponents:comps];
    return comps;
}

-(NSRange)timeStrRange{
    NSString *timeRegex = @"\\d{1,2}:\\d{1,2}(:\\d{1,2})?";
    NSRange timeRange = [self rangeOfString:timeRegex options:NSRegularExpressionSearch];
    return timeRange;
}

-(NSDateComponents *)parseTime:(NSRange)range{
    
    NSString *timeStr = [self substringWithRange:range];
    NSArray<NSString *> *components = [timeStr componentsSeparatedByString:@":"];
    int h = 0,mm = 0,s = 0;
    if (components.count!=1) {
        h = [components objectAtIndex:0].intValue;
        mm = [components objectAtIndex:1].intValue;
        if (components.count == 3) {
            s = [components objectAtIndex:2].intValue;
        }
        
    }
   
    
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    BOOL pm = [self rangeOfString:@"pm" options:NSRegularExpressionSearch|NSCaseInsensitiveSearch].length > 0;
    if(pm){
        h +=12;
    }
    comps.hour = h;
    comps.minute = mm;
    comps.second = s;
    [comps setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"] ];
   
    return comps;
}

-(BOOL)isPriceStr{
    NSString *regx = @"price";
    NSRange range = [self rangeOfString:regx options:NSRegularExpressionSearch|NSCaseInsensitiveSearch];
    return range.length > 0;
}

-(BOOL)isTotal{
    NSString *regx = @"total|balance|amount";
    NSRange range = [self rangeOfString:regx options:NSRegularExpressionSearch|NSCaseInsensitiveSearch];
    return range.length > 0;
}
-(double)parsePrice{
    //正则匹配三位小数
    NSString *priceRegex = @"\\d+\\.\\d{3}";
    double priceValue = 0;
    NSRange range = [self rangeOfString:priceRegex options:NSRegularExpressionSearch];
    if (range.length > 0 ) {
        NSString *price = [self substringWithRange:range];
        priceValue = [price doubleValue];
    }
    return priceValue;
}
-(double)parseTotal{
    //正则匹配两位小数
    NSString *priceRegex = @"\\d+\\.\\d{2}";
    double total = 0;
    NSRange range = [self rangeOfString:priceRegex options:NSRegularExpressionSearch];
    if (range.length > 0 ) {
        NSString *totalStr = [self substringWithRange:range];
        total = [totalStr doubleValue];
    }
    return total;
}
@end
