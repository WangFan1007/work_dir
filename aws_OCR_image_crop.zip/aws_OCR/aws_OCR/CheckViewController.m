//
//  CheckViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/30.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "CheckViewController.h"

@interface CheckViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextField *totaltf;
@property (weak, nonatomic) IBOutlet UITextField *pricetf;
@property (weak, nonatomic) IBOutlet UITextField *dateTf;
@property (weak, nonatomic) IBOutlet UITextField *timetf;

@property(nonatomic,strong) NSArray *totals;
@property(nonatomic,strong) NSArray *prices;
@property(nonatomic,strong) NSArray *dates;
@property(nonatomic,strong) NSArray *times;

@end

@implementation CheckViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}



-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.totals.firstObject) {
        self.totaltf.text = [NSString stringWithFormat:@"%@",self.totals.firstObject];
    }
    if (self.prices.firstObject) {
        self.pricetf.text = [NSString stringWithFormat:@"%@",self.prices.firstObject];
    }
    if (self.dates.firstObject) {
        self.dateTf.text = [NSString stringWithFormat:@"%@",self.dates.firstObject];
    }
    if (self.times.firstObject) {
        self.timetf.text = [NSString stringWithFormat:@"%@",self.times.firstObject];
    }
    
    self.imageView.image = self.img;
}

-(void)setResult:(NSDictionary<NSString *,NSArray *> *)result{
    _result = result;
    /*
     totals
     prices
     dates
     times*/
    self.totals = [result objectForKey:@"totals"];
    self.prices = [result objectForKey:@"prices"];
    self.dates = [result objectForKey:@"dates"];
    self.times = [result objectForKey:@"times"];
    
}

@end
