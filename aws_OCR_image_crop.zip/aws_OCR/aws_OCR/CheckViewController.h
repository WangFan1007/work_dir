//
//  CheckViewController.h
//  aws_OCR
//
//  Created by FFine on 2019/7/30.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CheckViewController : UIViewController
@property(strong,nonatomic) NSDictionary<NSString *,NSArray *> *result;
@property(strong,nonatomic) UIImage *img;
@end

NS_ASSUME_NONNULL_END
