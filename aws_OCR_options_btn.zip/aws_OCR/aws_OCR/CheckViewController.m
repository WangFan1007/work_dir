//
//  CheckViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/30.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "CheckViewController.h"
#import <IQKeyboardManager.h>
#import <Masonry.h>

@interface CheckViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UITextField *totaltf;
@property (weak, nonatomic) IBOutlet UITextField *pricetf;
@property (weak, nonatomic) IBOutlet UITextField *dateTf;
@property (weak, nonatomic) IBOutlet UITextField *timetf;

@property(nonatomic,strong) NSArray *totals;
@property(nonatomic,strong) NSArray *prices;
@property(nonatomic,strong) NSArray *dates;
@property(nonatomic,strong) NSArray *times;

@end

@implementation CheckViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpOptions];
    
}

-(void)setUpOptions{
    NSArray *titles = @[self.totals,self.prices,self.dates,self.times];
    NSArray *refs = @[self.totaltf,self.pricetf,self.dateTf,self.timetf];
    int tag = 0;
    for (NSArray *divideTitles in titles) {
        if (divideTitles.count < 2) {
            continue;
        }
        UIButton *prebtn = nil;
        
        for (id elenemt in divideTitles) {
            
            NSString *title = [NSString stringWithFormat:@"%@",elenemt];
            if ([elenemt isKindOfClass:NSNumber.class]) {
                double value = [elenemt doubleValue];
                if (tag == 0) {
                    title = [NSString stringWithFormat:@"%.2lf",value];
                }else{
                    title = [NSString stringWithFormat:@"%.3lf",value];
                }
                
            }
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [btn setTitle:title forState:UIControlStateNormal];
            [btn setTitleColor:UIColor.grayColor forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(optionBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            
            btn.layer.cornerRadius = 8;
            btn.layer.borderColor = [UIColor lightGrayColor].CGColor;
            btn.layer.borderWidth = 1;
            btn.titleLabel.font = [UIFont systemFontOfSize: 14.0];
            btn.tag = tag;
            [self.view addSubview:btn];
            CGSize titleSize = [title sizeWithAttributes:@{NSFontAttributeName: [UIFont fontWithName:btn.titleLabel.font.fontName size:btn.titleLabel.font.pointSize]}];
            UIView *ref = [refs objectAtIndex:tag];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(ref.mas_bottom).mas_offset(4);
                if (prebtn) {
                    make.left.equalTo(prebtn.mas_right).mas_offset(4);
                }else{
                    make.left.equalTo(ref.mas_left);
                }
                
                make.width.mas_equalTo(titleSize.width + 8);
                make.height.mas_equalTo(titleSize.height);
            }];
            prebtn = btn;
        }
        tag++;
    }
}

-(void)optionBtnClicked:(UIButton *)btn{
    NSArray *refs = @[self.totaltf,self.pricetf,self.dateTf,self.timetf];
    UITextField *tf = nil;
    tf = [refs objectAtIndex:btn.tag];
    tf.text = [btn titleForState:UIControlStateNormal];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (self.totals.firstObject) {
        self.totaltf.text = [NSString stringWithFormat:@"%@",self.totals.firstObject];
    }
    if (self.prices.firstObject) {
        self.pricetf.text = [NSString stringWithFormat:@"%@",self.prices.firstObject];
    }
    if (self.dates.firstObject) {
        self.dateTf.text = [NSString stringWithFormat:@"%@",self.dates.firstObject];
    }
    if (self.times.firstObject) {
        self.timetf.text = [NSString stringWithFormat:@"%@",self.times.firstObject];
    }
    
    self.imageView.image = self.img;
}

-(void)setResult:(NSDictionary<NSString *,NSArray *> *)result{
    _result = result;
    /*
     totals
     prices
     dates
     times*/
    self.totals = [result objectForKey:@"totals"];
    self.prices = [result objectForKey:@"prices"];
    self.dates = [result objectForKey:@"dates"];
    self.times = [result objectForKey:@"times"];
    
}

@end
