//
//  ViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "ViewController.h"
#import <AWSRekognition.h>
#import <AWSS3.h>
#import "NSString+Parser.h"
#import <UIImageView+WebCache.h>
#import <TOCropViewController.h>
#import <SVProgressHUD.h>
#import "CheckViewController.h"
#import <UIImageView+WebCache.h>


@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,TOCropViewControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *inputImg;
@property (weak, nonatomic) IBOutlet UITextView *outputText;
@property (weak, nonatomic) IBOutlet UITextField *urlTf;
@property (strong,nonatomic) NSString *url;
@end

@implementation ViewController


- (IBAction)selectImg:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:^{
        
    }];
}

- (IBAction)recogBtn:(id)sender {
    if ([self.urlTf.text length] > 0) {
        [self recogS3:self.urlTf.text];
    }
}

-(void)recogS3:(NSString *)s3url{
    self.url = s3url;
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    s3url = [s3url stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    //    cell.detailTextLabel.text = urlStr;
    NSURL *url = [NSURL URLWithString:s3url];
    NSString *path = url.path;
    path = [path stringByRemovingPercentEncoding];
    
    AWSRekognitionS3Object *s3obj = [[AWSRekognitionS3Object alloc] init];
    s3obj.bucket = [[url.host componentsSeparatedByString:@"."] firstObject];
    s3obj.name = [path substringFromIndex:1];
    [image setS3Object:s3obj];
    //    NSData *bytes = [NSData dataWithContentsOfURL:url];
    //    self.inputImg.image = [UIImage imageWithData:bytes];
    //    [image setBytes:bytes];
    
    [req setImage:image];
    [self recogWithReq:req];
    //preview
//    NSData *bytes = [NSData dataWithContentsOfURL:url];
//    self.inputImg.image = [UIImage imageWithData:bytes];
    [self.inputImg sd_setImageWithURL:url];
}



-(NSDictionary<NSString *,NSArray *> *)findRawPriceNTotal:(NSArray<AWSRekognitionTextDetection *> * )textDetections interval:(NSTimeInterval) interval{
    
    NSDictionary<NSString *,NSMutableArray *> *raws = @{@"prices":[[NSMutableArray alloc] init],
                           @"totals":[[NSMutableArray alloc] init]
                           };
    for (AWSRekognitionTextDetection *textDetection in textDetections) {
        //正则匹配两位小数
        NSString *total = @"\\d+\\.\\d{2}";
        
        NSRange range = [textDetection.detectedText rangeOfString:total options:NSRegularExpressionSearch];
        if (range.length > 0 ) {
            NSString *t = [textDetection.detectedText substringWithRange:range];
            double temp = [t doubleValue];
            [[raws objectForKey:@"totals"] addObject:@(temp)];
        }
        
        NSString *price = @"\\d+\\.\\d{3}";
        
        NSRange rangePrice = [textDetection.detectedText rangeOfString:price options:NSRegularExpressionSearch];
        if (rangePrice.length > 0 ) {
            NSString *prs = [textDetection.detectedText substringWithRange:rangePrice];
            double temp = [prs doubleValue];
            [[raws objectForKey:@"prices"] addObject:@(temp)];
        }
    }
    return raws;
}


-(NSArray<NSString *> *)findLinesByFamilys:(NSArray<AWSRekognitionTextDetection *> * )textDetections{
    NSMutableDictionary *parents = [[NSMutableDictionary alloc] init];
    for (AWSRekognitionTextDetection *detection in textDetections) {
        if (detection.parentId == nil) {
            NSMutableArray *line = [[NSMutableArray alloc] init];
            [line addObject:detection];
            [parents setObject:line forKey:detection];
        }
    }
    for (AWSRekognitionTextDetection *parent in parents.allKeys) {
        for (AWSRekognitionTextDetection *detection in textDetections) {
            if ([detection.parentId isEqualToNumber:parent.identifier]) {
                NSMutableArray *arr = [parents objectForKey:parent];
                [arr addObject:detection];
            }
        }
    }
    NSMutableArray *lines = [[NSMutableArray alloc] init];
    for (AWSRekognitionTextDetection *parent in parents.allKeys) {
//        NSLog(@"%ld %@",(long)parent.types,parent.detectedText);
        NSMutableString *line = [[NSMutableString alloc] init];
        [line appendString:parent.detectedText];
        [lines addObject:line];
        NSArray *arr = [parents objectForKey:parent];
        for (AWSRekognitionTextDetection *child in arr) {
            if (![line containsString:child.detectedText]) {
                NSCharacterSet *cs = NSCharacterSet.whitespaceAndNewlineCharacterSet;
                NSString *text = [child.detectedText stringByTrimmingCharactersInSet:cs];
                [line appendString:text];
            }
        }
    }
//    for (NSString *str in lines) {
//        NSLog(@"--%@",str);
//    }
    return lines;
}

-(NSDictionary<NSString *,NSMutableArray *> *)analyzeLines:(NSArray<NSString *> *)strLines rawprice:(NSDictionary<NSString *,NSArray *> *)rawprice{
    NSDictionary<NSString *,NSMutableArray *> *results = @{
                              @"totals":[[NSMutableArray alloc] init],
                              @"prices":[[NSMutableArray alloc] init],
                              @"dates":[[NSMutableArray alloc] init],
                              @"times":[[NSMutableArray alloc] init]
                              };
    for (NSString *line in strLines) {
        if ([line isTotal]) {
            double total = line.parseTotal;
            NSMutableArray *t = [results objectForKey:@"totals"];
            if (![t containsObject:@(total)]) {
                [[results objectForKey:@"totals"] addObject:@(total)];
            }
        }
        if ([line isPriceStr]) {
            double price = line.parsePrice;
            NSMutableArray *p = [results objectForKey:@"prices"];
            if (![p containsObject:@(price)]) {
                [p addObject:@(price)];
            }
        }
        NSRange dateStrRange = [line dateStrRange];
        if (dateStrRange.length > 0) {
            NSString *date = [line substringWithRange:dateStrRange];
            NSMutableArray *d = [results objectForKey:@"dates"];
            if (![d containsObject:date]) {
                [d addObject:date];
            }
        }
        
        NSRange timeStrRange = [line timeStrRange];
        if (timeStrRange.length > 0) {
            NSString *time = [line substringWithRange:timeStrRange];
            NSMutableArray *t = [results objectForKey:@"times"];
            if (![t containsObject:time]) {
                [t addObject:time];
            }
        }
    }
    NSMutableArray *emptyKeys = [[NSMutableArray alloc] init];
    for (NSString *key in results.allKeys) {
        NSMutableArray *temp = [results objectForKey:key];
        if (temp.count == 0) {
            [emptyKeys addObject:key];
        }
    }
    
    for (NSString* emptyKey in emptyKeys) {
        if ([emptyKey isEqualToString:@"prices"] || [emptyKey isEqualToString:@"totals"]) {
            for (id elenemt in [rawprice objectForKey:emptyKey]) {
                if (![[results objectForKey:emptyKey] containsObject:elenemt]) {
                    [[results objectForKey:emptyKey] addObject:elenemt];
                }
            }
        }
        
    }
    return results;
}


-(void)recogWithReq:(AWSRekognitionDetectTextRequest *)req{
    AWSRekognition *rek = [AWSRekognition defaultRekognition];
    NSDate *start = [NSDate date];
    [SVProgressHUD showWithStatus:@"Recognizing..."];
    [rek detectText:req completionHandler:^(AWSRekognitionDetectTextResponse * _Nullable response, NSError * _Nullable error) {
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:start];
        NSLog(@"use time %f",interval);
        [SVProgressHUD dismiss];
        if (!error) {
            NSDictionary<NSString *,NSArray *> *dic = [self findRawPriceNTotal:response.textDetections interval:interval];
            NSArray<NSString *> *strLines = [self findLinesByFamilys:response.textDetections];
            NSLog(@"final lines: %@",strLines);
            NSDictionary<NSString *,NSMutableArray *> *result = [self analyzeLines:strLines rawprice:dic];
            NSLog(@"%@",result);
            dispatch_async(dispatch_get_main_queue(), ^{
                CheckViewController *vc = [[CheckViewController alloc] init];
                vc.result = result;
                if (self.url) {
                    vc.url = self.url;
                }else{
                    vc.img = self.inputImg.image;
                }
                
                
                [self.navigationController pushViewController:vc animated:YES];
            });
        }else{
            NSLog(@"%@",error);
            dispatch_async(dispatch_get_main_queue(), ^{
                self.outputText.text = [NSString stringWithFormat:@"%@",error];
            });
            [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"%@",error]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }
        
            
        
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.outputText.editable = NO;
    self.outputText.text = @"please wait...";
    NSMutableArray *arr = [NSMutableArray arrayWithArray:nil];
    [arr addObject:@"hello"];
}

    
-(void)uploadImage:(UIImage *)image{
    AWSS3 *s3 = [AWSS3 defaultS3];
    AWSS3PutObjectRequest *preq = [[AWSS3PutObjectRequest alloc] init];
    preq.key = [NSString stringWithFormat:@"images/%@.jpg",[[NSUUID UUID] UUIDString]];
    preq.bucket = @"triplog-ocr";
    NSData *data = UIImageJPEGRepresentation(image, 0.5);
    preq.body = data;
    
    preq.contentLength = @(data.length);
    preq.contentType = @"image/jpeg";
    
    [SVProgressHUD showWithStatus:@"upload image..."];
    [s3 putObject:preq completionHandler:^(AWSS3PutObjectOutput * _Nullable response, NSError * _Nullable error) {
        [SVProgressHUD dismiss];
        if (!error) {
            NSLog(@"---r%@",response);
            AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
            AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
            AWSRekognitionS3Object *s3obj = [[AWSRekognitionS3Object alloc] init];
            s3obj.bucket = preq.bucket;
            s3obj.name = preq.key;
            [image setS3Object:s3obj];
            [req setImage:image];
            [self recogWithReq:req];
            
        }else{
            NSLog(@"---e%@",error);
            [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"%@",error]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [SVProgressHUD dismiss];
            });
        }
        
    }];
//    [self recogImg:image];

}
    
#pragma handle image
-(void)cropViewController:(TOCropViewController *)cropViewController didCropToImage:(UIImage *)image withRect:(CGRect)cropRect angle:(NSInteger)angle{
    [cropViewController dismissViewControllerAnimated:YES completion:^{
        self.inputImg.image = image;
        //upload image
        [self uploadImage:image];
    }];
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    NSLog(@"%@",info);
    
    UIImage *originalImg = [info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:^{

        TOCropViewController *cropVC = [[TOCropViewController alloc] initWithImage:originalImg];
        cropVC.delegate = self;
        [self presentViewController:cropVC animated:YES completion:nil] ;
    }];
}

@end
