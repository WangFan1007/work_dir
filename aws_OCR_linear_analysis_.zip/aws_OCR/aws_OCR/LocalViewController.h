//
//  LocalViewController.h
//  aws_OCR
//
//  Created by FFine on 2019/7/25.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LocalViewController : UIViewController
@property (weak,nonatomic) UIViewController *preController;
@end

NS_ASSUME_NONNULL_END
