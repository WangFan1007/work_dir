//
//  TableViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/25.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong,nonatomic) NSArray<NSString *> *urls;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation TableViewController

- (IBAction)close:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"images" ofType:@"txt"];
    NSString *contents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    self.urls = [contents componentsSeparatedByString:@"\n"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.urls count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellIds = @"cellIds";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIds];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIds];
    }
    NSString *urlStr = [self.urls objectAtIndex:indexPath.row];
    urlStr = [urlStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    cell.detailTextLabel.text = urlStr;
    NSURL *url = [NSURL URLWithString:urlStr];
    NSArray<NSString *>* strings =  [url.path componentsSeparatedByString:@"/"];
    cell.detailTextLabel.text = [strings objectAtIndex:2];
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self dismissViewControllerAnimated:YES completion:^{
        NSString *url = [self.urls objectAtIndex:indexPath.row];
        [self.preController setValue:url forKey:@"s3url4detect"];
    }];
}

@end
