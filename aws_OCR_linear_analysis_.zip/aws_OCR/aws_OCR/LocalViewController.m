//
//  LocalViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/25.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "LocalViewController.h"

@interface LocalViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong,nonatomic) NSArray<NSString *> *paths;
@end

@implementation LocalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"imgnames" ofType:@"txt"];
    NSString *contents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    self.paths = [contents componentsSeparatedByString:@"\n"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}
- (IBAction)close:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.paths count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *cellIds = @"cellIds";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIds];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIds];
    }
    NSString *urlStr = [self.paths objectAtIndex:indexPath.row];
    cell.detailTextLabel.text = [urlStr lastPathComponent];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self dismissViewControllerAnimated:YES completion:^{
        NSString *fileName = [self.paths objectAtIndex:indexPath.row];
        [self.preController setValue:fileName forKey:@"image4detect"];
    }];
}

@end
