//
//  main.m
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
