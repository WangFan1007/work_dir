//
//  ViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "ViewController.h"
#import <AWSRekognition.h>
#import "NSString+Parser.h"
#import "TableViewController.h"
#import <UIImageView+WebCache.h>

#define AWS_ACCESS_KEY @"AKIAIQS5QGRXPYLTIZVQ"
#define AWS_SECRET_KEY @"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"


@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *inputImg;
@property (weak, nonatomic) IBOutlet UITextView *outputText;

@property (strong,nonatomic) NSString *s3url4detect;
@property (strong,nonatomic) NSString *image4detect;
@end

@implementation ViewController


- (IBAction)selectImg:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:^{
        
    }];
}

-(void)setS3url4detect:(NSString *)s3url4detect{
    _s3url4detect = s3url4detect;
    [self recogS3:s3url4detect];
}

-(void)setImage4detect:(NSString *)image4detect{
    NSLog(@"file name: %@",image4detect);
    _image4detect = image4detect;
    self.inputImg.image = [UIImage imageNamed:image4detect];
    NSString *path = [[NSBundle mainBundle] pathForResource:image4detect ofType:nil];
    [self recogFile:path];
}




-(void)findDateTimeMax:(NSArray<AWSRekognitionTextDetection *> * )textDetections interval:(NSTimeInterval) interval{
    double maxPrice = 0;
    NSString *dateStr = nil;
    NSString *timeStr = nil;
    for (AWSRekognitionTextDetection *textDetection in textDetections) {
        //正则匹配两位小数
        NSString *priceRegex = @"\\d+\\.\\d{2}";
        
        NSRange range = [textDetection.detectedText rangeOfString:priceRegex options:NSRegularExpressionSearch];
        if (range.length > 0 ) {
            NSString *price = [textDetection.detectedText substringWithRange:range];
            double temp = [price doubleValue];
            if (temp>maxPrice) {
                maxPrice = temp;
            }
        }
        
        NSString *dateRegex = @"\\d{1,4}[/-]\\d{1,4}[/-]\\d{1,4}";
        NSRange dateRange = [textDetection.detectedText rangeOfString:dateRegex options:NSRegularExpressionSearch];
        if (dateRange.length > 0) {
            dateStr = textDetection.detectedText;
        }
        
        NSString *timeRegex = @"\\d{1,2}:\\d{1,2}(:\\d{1,2})?";
        NSRange timeRange = [textDetection.detectedText rangeOfString:timeRegex options:NSRegularExpressionSearch];
        if (timeRange.length > 0) {
            timeStr = textDetection.detectedText;
        }
        
    }
    NSString *priceTag = [NSString stringWithFormat:@"maxPrice = %lf",maxPrice];
    NSLog(@"%@", priceTag);
    NSString *dateTag = [NSString stringWithFormat:@"dateStr =  %@",dateStr];
    NSLog(@"%@", dateTag);
    NSString *timeTag = [NSString stringWithFormat:@"timeStr = %@",timeStr];
    NSLog(@"%@", timeTag);
    dispatch_async(dispatch_get_main_queue(), ^{
        self.outputText.text = [NSString stringWithFormat:@"%@\n%@\n%@\nuse time %f",priceTag,dateTag,timeTag,interval];
    });
}


-(NSArray<NSString *> *)concatLines:(NSArray<NSArray *> *)lines{
    NSMutableArray<NSString *> *strLines = [[NSMutableArray alloc] init];
    for (NSArray *arr in lines) {
        NSArray<AWSRekognitionTextDetection *> *sorted = [arr sortedArrayUsingComparator:^NSComparisonResult(AWSRekognitionTextDetection* obj1, AWSRekognitionTextDetection* obj2) {
            AWSRekognitionPoint *p1 = [obj1.geometry.polygon objectAtIndex:0];
            AWSRekognitionPoint *p2 = [obj1.geometry.polygon objectAtIndex:1];
            double deltaX = p2.X.doubleValue - p1.X.doubleValue;
            double deltaY = p2.Y.doubleValue - p1.Y.doubleValue;
            if (ABS(deltaX) > ABS(deltaY)) {
                return deltaX;
            }else{
                return deltaY;
            }
        }];
        NSMutableString *line = [[NSMutableString alloc] init];
        for (AWSRekognitionTextDetection *detection in sorted) {
            if ([line containsString:detection.detectedText]) {
                continue;
            }
            [line appendString:detection.detectedText];
        }
        [strLines addObject:line];
    }
    return strLines;
}





-(NSArray<NSArray *> *)findLines:(NSArray<AWSRekognitionTextDetection *> * )textDetections{
    
    NSMutableArray<NSArray *> *lines = [[NSMutableArray alloc] init];
    for (AWSRekognitionTextDetection *outer_detection in textDetections) {
        if (outer_detection.parentId!=nil) {
            continue;
        }
        for (AWSRekognitionTextDetection *inner_detection in textDetections) {
            if (inner_detection.parentId!=nil || inner_detection == outer_detection) {
                continue;
            }
            AWSRekognitionPoint *p1 = [outer_detection.geometry.polygon objectAtIndex:0];
            AWSRekognitionPoint *p2 = [outer_detection.geometry.polygon objectAtIndex:1];
            AWSRekognitionPoint *p3 = [inner_detection.geometry.polygon objectAtIndex:0];
            AWSRekognitionPoint *p4 = [inner_detection.geometry.polygon objectAtIndex:1];
            
            double deltaX = p2.X.doubleValue - p1.X.doubleValue;
            double deltaY = p2.Y.doubleValue - p1.Y.doubleValue;
            double k1 = 0,k2 = 0,k3 = 0,threshold = 0;
            if (ABS(deltaX) > ABS(deltaY)) {
                k1 = (p2.Y.doubleValue - p1.Y.doubleValue)/(p2.X.doubleValue - p1.X.doubleValue);
                k2 = (p3.Y.doubleValue - p2.Y.doubleValue)/(p3.X.doubleValue - p2.X.doubleValue);
                k3 = (p4.Y.doubleValue - p3.Y.doubleValue)/(p4.X.doubleValue - p3.X.doubleValue);
                threshold = 0.066;
            }else{
                k1 = (p2.X.doubleValue - p1.X.doubleValue)/(p2.Y.doubleValue - p1.Y.doubleValue);
                k2 = (p3.X.doubleValue - p2.X.doubleValue)/(p3.Y.doubleValue - p2.Y.doubleValue);
                k3 = (p4.X.doubleValue - p3.X.doubleValue)/(p4.Y.doubleValue - p3.Y.doubleValue);
                threshold = 0.048;
            }
            
            double factor = sqrt((pow(k1, 2) + pow(k2, 2) + pow(k3, 2))/3);
            NSLog(@"%@|%@ %lf",outer_detection.detectedText,inner_detection.detectedText,factor);
            //$36.44|Debit VS 0.065116
            //Debit VS|$36.44 0.063414
            if (factor < threshold) {//same line
                [lines addObject:@[outer_detection,inner_detection]];
            }
        }
    }
    NSMutableArray<NSArray *> *finalLines = [[NSMutableArray alloc] init];
    for (int i = 0; i<lines.count; i++) {
        NSArray *outer_line = [lines objectAtIndex:i];
        NSMutableSet *tempLine = [[NSMutableSet alloc] init];
        [tempLine addObjectsFromArray:outer_line];
        for (int j = i+1; i<lines.count-1; j++) {
            if (j>lines.count -1) {
                break;
            }
            NSArray *inner_line = [lines objectAtIndex:j];
            for (AWSRekognitionTextDetection *detection in outer_line) {
                if ([inner_line containsObject:detection]) {
                    [tempLine addObjectsFromArray:inner_line];
                    break;
                }
            }
        }
        [finalLines addObject:[tempLine allObjects]];
    }
    
    return finalLines;
}

-(void)recogImg:(UIImage *)inputImg{
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    [image setBytes:UIImageJPEGRepresentation(inputImg, 0.5)];
    [req setImage:image];
    [self recogWithReq:req];
}

-(void)recogFile:(NSString *)filePath{
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    [image setBytes:[NSData dataWithContentsOfFile:filePath]];
    [req setImage:image];
    [self recogWithReq:req];
}

-(void)recogS3:(NSString *)s3url{
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    s3url = [s3url stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    //    cell.detailTextLabel.text = urlStr;
    NSURL *url = [NSURL URLWithString:s3url];
    NSString *path = url.path;
//    path = [path stringByRemovingPercentEncoding];

    AWSRekognitionS3Object *s3obj = [[AWSRekognitionS3Object alloc] init];
    s3obj.bucket = [[url.host componentsSeparatedByString:@"."] firstObject];
    s3obj.name = [path substringFromIndex:1];
    [image setS3Object:s3obj];
    
    [req setImage:image];
    [self recogWithReq:req];
    //preview
    [self.inputImg sd_setImageWithURL:url];
    
}


-(void)recogWithReq:(AWSRekognitionDetectTextRequest *)req{
    AWSRekognition *rek = [AWSRekognition defaultRekognition];
    NSDate *start = [NSDate date];
    self.outputText.text = @"please wait...";
    
    [rek detectText:req completionHandler:^(AWSRekognitionDetectTextResponse * _Nullable response, NSError * _Nullable error) {
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:start];
        NSLog(@"use time %f",interval);
        if (!error) {
//            [self findDateTimeMax:response.textDetections interval:interval];
            
            NSArray<NSArray *> *lines = [self findLines:response.textDetections];
            NSArray<NSString *> *strLines = [self concatLines:lines];
            NSLog(@"final lines: %@",strLines);
            double total = 0,price = 0;
            NSDateComponents *date = nil, *time = nil;
            for (NSString *line in strLines) {
                if ([line isTotal]) {
                    NSLog(@"total line value is: %lf",line.parseTotal);
                    total = line.parseTotal;
                }
                if ([line isPriceStr]) {
                    NSLog(@"price line value is: %lf",line.parsePrice);
                    price = line.parsePrice;
                }
                NSRange dateStrRange = [line dateStrRange];
                if (dateStrRange.length > 0) {
                    NSLog(@"date line value is: %@",[line parseDate:dateStrRange]);
                    date = [line parseDate:dateStrRange];
                }
                
                NSRange timeStrRange = [line timeStrRange];
                if (timeStrRange.length > 0) {
                    NSLog(@"date line value is: %@",[line parseTime:timeStrRange]);
                    time = [line parseTime:timeStrRange];
                }
            }
            NSCalendar * calendar = [NSCalendar currentCalendar];
            NSDateComponents *coplex = [calendar componentsInTimeZone:NSTimeZone.defaultTimeZone fromDate:[NSDate date]];
            
            if (date) {
                coplex.year = date.year;
                coplex.month = date.month;
                coplex.day = date.day;
            }
            if (time) {
                coplex.hour = time.hour;
                coplex.minute = time.minute;
                coplex.second = time.second;
            }
            NSDate * datetime = [calendar dateFromComponents:coplex];
            NSString *result = [NSString stringWithFormat:@"total: %lf\nprice: %lf\ndate: %@",total,price,datetime];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.outputText.text = result;
            });
            
        }else{
            NSLog(@"%@",error);
            self.outputText.text = [NSString stringWithFormat:@"%@",error];
        }
        
        
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.outputText.editable = NO;
    self.outputText.text = @"please wait...";
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    NSLog(@"%@",info);
    
    UIImage *originalImg = [info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:^{
        self.inputImg.image = originalImg;
        [self recogImg:originalImg];
    }];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"totable"]||[segue.identifier isEqualToString:@"tolocal"]) {
        [((TableViewController *)segue.destinationViewController) setPreController:self];
    }
}

@end
