//
//  NSString+Parser.h
//  aws_OCR
//
//  Created by FFine on 2019/7/24.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Parser)

-(double)parsePrice;
-(double)parseTotal;

-(BOOL)isPriceStr;
-(BOOL)isTotal;
-(NSRange)dateStrRange;
-(NSRange)timeStrRange;
-(NSDateComponents *)parseDate:(NSRange)range;
-(NSDateComponents *)parseTime:(NSRange)range;
@end

NS_ASSUME_NONNULL_END
