//
//  ViewController.h
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

