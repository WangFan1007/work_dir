//
//  ViewController.m
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import "ViewController.h"
#import <AWSRekognition.h>
#import "NSString+Parser.h"
#import "TableViewController.h"

#define AWS_ACCESS_KEY @"AKIAIQS5QGRXPYLTIZVQ"
#define AWS_SECRET_KEY @"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"


@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *inputImg;
@property (weak, nonatomic) IBOutlet UITextView *outputText;

@property (strong,nonatomic) NSString *s3url4detect;
@end

@implementation ViewController


- (IBAction)selectImg:(id)sender {
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:^{
        
    }];
}

-(void)setS3url4detect:(NSString *)s3url4detect{
    _s3url4detect = s3url4detect;
    [self recogS3:s3url4detect];
}




-(void)findDateTimeMax:(NSArray<AWSRekognitionTextDetection *> * )textDetections interval:(NSTimeInterval) interval{
    double maxPrice = 0;
    NSString *dateStr = nil;
    NSString *timeStr = nil;
    for (AWSRekognitionTextDetection *textDetection in textDetections) {
        //正则匹配两位小数
        NSString *priceRegex = @"\\d+\\.\\d{2}";
        
        NSRange range = [textDetection.detectedText rangeOfString:priceRegex options:NSRegularExpressionSearch];
        if (range.length > 0 ) {
            NSString *price = [textDetection.detectedText substringWithRange:range];
            double temp = [price doubleValue];
            if (temp>maxPrice) {
                maxPrice = temp;
            }
        }
        
        NSString *dateRegex = @"\\d{1,4}[/-]\\d{1,4}[/-]\\d{1,4}";
        NSRange dateRange = [textDetection.detectedText rangeOfString:dateRegex options:NSRegularExpressionSearch];
        if (dateRange.length > 0) {
            dateStr = textDetection.detectedText;
        }
        
        NSString *timeRegex = @"\\d{1,2}:\\d{1,2}(:\\d{1,2})?";
        NSRange timeRange = [textDetection.detectedText rangeOfString:timeRegex options:NSRegularExpressionSearch];
        if (timeRange.length > 0) {
            timeStr = textDetection.detectedText;
        }
        
    }
    NSString *priceTag = [NSString stringWithFormat:@"maxPrice = %lf",maxPrice];
    NSLog(@"%@", priceTag);
    NSString *dateTag = [NSString stringWithFormat:@"dateStr =  %@",dateStr];
    NSLog(@"%@", dateTag);
    NSString *timeTag = [NSString stringWithFormat:@"timeStr = %@",timeStr];
    NSLog(@"%@", timeTag);
    dispatch_async(dispatch_get_main_queue(), ^{
        self.outputText.text = [NSString stringWithFormat:@"%@\n%@\n%@\nuse time %f",priceTag,dateTag,timeTag,interval];
    });
}


-(NSArray<NSString *> *)concatLines:(NSDictionary<NSNumber *,NSArray *> *)lines
                        orientation:(UIImageOrientation)orientation{
    NSMutableArray<NSString *> *strLines = [[NSMutableArray alloc] init];
    NSArray *sortedKeys = [lines.allKeys sortedArrayUsingComparator:^NSComparisonResult(NSNumber * obj1, NSNumber * obj2) {
        if (obj1.integerValue > obj2.integerValue) {
            return NSOrderedDescending;
        }else{
            return NSOrderedAscending;
        }
    }];
    for (NSNumber *key in sortedKeys) {
        NSArray *lineDetections = [lines objectForKey:key];
        NSArray *sortedLine = [lineDetections sortedArrayUsingComparator:^NSComparisonResult(AWSRekognitionTextDetection * obj1, AWSRekognitionTextDetection * obj2) {
            float x1 = obj1.geometry.boundingBox.left.floatValue;
            float x2 = obj1.geometry.boundingBox.left.floatValue;
            
            float y1 = obj1.geometry.boundingBox.top.floatValue;
            float y2 = obj1.geometry.boundingBox.top.floatValue;
            
            switch (orientation) {
                case UIImageOrientationUp:
                    return x2 - x1;
                case UIImageOrientationDown:
                    return x1 - x2;
                case UIImageOrientationLeft:
                    return y2 - y1;
                case UIImageOrientationRight:
                    return y1 - y2;
                default:
                    break;
            }
            return NSOrderedAscending;
        }];
        NSMutableString *line = [[NSMutableString alloc] init];
        [strLines addObject:line];
        for (AWSRekognitionTextDetection *elem in sortedLine) {
            if (![line containsString:elem.detectedText]) {
                [line appendFormat:@" %@",elem.detectedText];
            }
        }
    }
    return strLines;
}

-(UIImageOrientation)getOrientation:(AWSRekognitionTextDetection *)detect{
    NSArray<AWSRekognitionPoint *> *polygon = detect.geometry.polygon;
    UIImageOrientation orientation = UIImageOrientationUp;
    AWSRekognitionPoint *firstP = [polygon objectAtIndex:0];
    AWSRekognitionPoint *secondP = [polygon objectAtIndex:1];
    int x1 = floor(firstP.X.doubleValue * 100);
    int x2 = floor(secondP.X.doubleValue * 100);
    int y1 = floor(firstP.Y.doubleValue * 100);
    int y2 = floor(secondP.Y.doubleValue * 100);
    if (x2 - x1 > 0) {
        orientation = UIImageOrientationUp;
    }else if (x2 - x1 < 0){
        orientation = UIImageOrientationDown;
    }
    
    if (y2 - y1 < 0) {
        orientation = UIImageOrientationLeft;
    }
    if (y2 - y1 > 0) {
        orientation = UIImageOrientationRight;
    }
    
    return orientation;
}

-(NSDictionary<NSNumber *,NSArray *> *)findLines:(NSArray<AWSRekognitionTextDetection *> * )textDetections
                                     orientation:(UIImageOrientation)orientation{
    
    NSMutableDictionary<NSNumber *,NSMutableArray *> *lines = [[NSMutableDictionary alloc] init];
    for (AWSRekognitionTextDetection *detection in textDetections) {
        int level = 0;
        switch (orientation) {
            case UIImageOrientationUp:
                level = floor(detection.geometry.boundingBox.top.doubleValue * 100) ;
                break;
            case UIImageOrientationDown:
                level = floor(detection.geometry.boundingBox.top.doubleValue * 100) ;
                break;
            case UIImageOrientationLeft:
                level = floor(detection.geometry.boundingBox.left.doubleValue * 100) ;
                break;
            case UIImageOrientationRight:
                level = floor(detection.geometry.boundingBox.left.doubleValue * 100) ;
                break;
                
            default:
                break;
        }
        
        NSMutableArray *line = [lines objectForKey:@(level)];
        if (!line) {
            line = [[NSMutableArray alloc] init];
            [lines setObject:line forKey:@(level)];
        }
        [line addObject:detection];
    }
    return lines;
}

-(void)recogImg:(UIImage *)inputImg{
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    [image setBytes:UIImageJPEGRepresentation(inputImg, 0.5)];
    [req setImage:image];
    [self recogWithReq:req];
}

-(void)recogS3:(NSString *)s3url{
    AWSRekognitionDetectTextRequest *req = [[AWSRekognitionDetectTextRequest alloc] init];
    AWSRekognitionImage *image = [[AWSRekognitionImage alloc] init];
    s3url = [s3url stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    //    cell.detailTextLabel.text = urlStr;
    NSURL *url = [NSURL URLWithString:s3url];
    NSString *path = url.path;
    path = [path stringByRemovingPercentEncoding];

    AWSRekognitionS3Object *s3obj = [[AWSRekognitionS3Object alloc] init];
    s3obj.bucket = [[url.host componentsSeparatedByString:@"."] firstObject];
    s3obj.name = [path substringFromIndex:1];
    [image setS3Object:s3obj];
//    NSData *bytes = [NSData dataWithContentsOfURL:url];
//    self.inputImg.image = [UIImage imageWithData:bytes];
//    [image setBytes:bytes];
    
    [req setImage:image];
    [self recogWithReq:req];
    //preview
    NSData *bytes = [NSData dataWithContentsOfURL:url];
    self.inputImg.image = [UIImage imageWithData:bytes];
}


-(void)recogWithReq:(AWSRekognitionDetectTextRequest *)req{
    AWSRekognition *rek = [AWSRekognition defaultRekognition];
    NSDate *start = [NSDate date];
    self.outputText.text = @"please wait...";
    
    [rek detectText:req completionHandler:^(AWSRekognitionDetectTextResponse * _Nullable response, NSError * _Nullable error) {
        NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:start];
        NSLog(@"use time %f",interval);
        if (!error) {
            [self findDateTimeMax:response.textDetections interval:interval];
            
            UIImageOrientation orientation = [self getOrientation:response.textDetections.firstObject];
            NSDictionary<NSNumber *,NSArray *> *lines = [self findLines:response.textDetections orientation:orientation];
            NSArray<NSString *> *strLines = [self concatLines:lines orientation:orientation];
            NSLog(@"%@",strLines);
            for (NSString *line in strLines) {
                if ([line isTotal]) {
                    NSLog(@"total line value is: %lf",line.parseTotal);
                }
                if ([line isPriceStr]) {
                    NSLog(@"price line value is: %lf",line.parsePrice);
                }
                NSRange dateStrRange = [line dateStrRange];
                if (dateStrRange.length > 0) {
                    NSLog(@"date line value is: %@",[line parseDate:dateStrRange]);
                }
                
                NSRange timeStrRange = [line timeStrRange];
                if (timeStrRange.length > 0) {
                    NSLog(@"date line value is: %@",[line parseTime:timeStrRange]);
                }
            }
            
        }else{
            NSLog(@"%@",error);
        }
        
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.outputText.editable = NO;
    self.outputText.text = @"please wait...";
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<UIImagePickerControllerInfoKey,id> *)info{
    NSLog(@"%@",info);
    
    UIImage *originalImg = [info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:^{
        self.inputImg.image = originalImg;
        [self recogImg:originalImg];
    }];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"totable"]) {
        [((TableViewController *)segue.destinationViewController) setPreController:self];
    }
}

@end
