//
//  AppDelegate.h
//  aws_OCR
//
//  Created by FFine on 2019/7/17.
//  Copyright © 2019 FFine. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

